"""Receive a compressed ECG frame over UART, decode it, and score it.

The decoder is the Phase 1 reference decoder, unmodified. That is the point: the
hardware passes only if the same code that validated the algorithm also reconstructs
the hardware's output, and the received frame is byte-identical to the golden one.

Three sources, all feeding the same parser:

    --port COM5            live board over the PS UART (the PROG micro-USB COM port)
    --file capture.bin     a previously captured byte stream
    --loopback 100         a frame synthesised from the reference model (no hardware)

The loopback mode is the desktop gate for Phase 5: it proves the receiver, the
transport framing and the decoder agree with run_reference.py before any board is
involved.

Usage:
    python python/scripts/serial_rx.py --loopback 100
    python python/scripts/serial_rx.py --port COM5 --record 100 --save capture.bin
"""

from __future__ import annotations

import argparse
import sys
import time

import _bootstrap  # noqa: F401
import numpy as np

from ecg_ref import config, metrics, packer, pipeline, preprocess

PREAMBLE_BYTES = config.UART_PREAMBLE_WORDS * 4


class FrameError(Exception):
    pass


def build_transport_frame(words: list[int], latency_cycles: int = 0) -> bytes:
    """Wrap a compressed frame the way ps/src/main.c does.

    Kept here rather than only in the firmware so the loopback path exercises the exact
    byte layout the board emits.
    """
    preamble = [config.UART_SYNC_MAGIC, len(words), latency_cycles]
    return b"".join(w.to_bytes(4, "big") for w in preamble + words)


def read_transport_frame(read_exact, resync_limit: int = 1 << 16) -> tuple[bytes, int]:
    """Find the sync word, then read one complete frame.

    Returns (frame_bytes, latency_cycles). `read_exact(n)` must return exactly n bytes
    or raise. Resynchronising byte by byte matters on a real link, where the receiver
    is usually started midway through the board's boot chatter.
    """
    sync = config.UART_SYNC_MAGIC.to_bytes(4, "big")
    window = read_exact(4)
    skipped = 0
    while window != sync:
        if skipped >= resync_limit:
            raise FrameError(f"no sync word in the first {resync_limit} bytes")
        window = window[1:] + read_exact(1)
        skipped += 1
    if skipped:
        print(f"  resynchronised after {skipped} stray byte(s)")

    frame_words = int.from_bytes(read_exact(4), "big")
    latency_cycles = int.from_bytes(read_exact(4), "big")
    if not 0 < frame_words <= (1 << 22):
        raise FrameError(f"implausible frame length: {frame_words} words")

    return read_exact(frame_words * 4), latency_cycles


def reader_from_bytes(payload: bytes):
    """read_exact over an in-memory buffer."""
    state = {"pos": 0}

    def read_exact(n: int) -> bytes:
        start = state["pos"]
        chunk = payload[start:start + n]
        if len(chunk) != n:
            raise FrameError(f"stream truncated: wanted {n} bytes at offset {start}")
        state["pos"] = start + n
        return chunk

    return read_exact


def reader_from_serial(port: str, baud: int, timeout: float):
    try:
        import serial  # noqa: PLC0415  (optional dependency; only the board path needs it)
    except ImportError as exc:  # pragma: no cover
        raise SystemExit("pyserial is required for --port; pip install pyserial") from exc

    link = serial.Serial(port, baud, timeout=timeout)
    print(f"listening on {port} at {baud} baud")

    def read_exact(n: int) -> bytes:
        chunk = link.read(n)
        if len(chunk) != n:
            raise FrameError(f"serial timeout: got {len(chunk)} of {n} bytes")
        return chunk

    return read_exact, link


def evaluate(frame: bytes, record: str | None) -> dict:
    """Decode a received frame and, if the record is known, score it."""
    # #region agent log
    def _dbg(hid: str, msg: str, data: dict) -> None:
        import json, time
        try:
            with open(r"C:\Users\elina\Moved_files\Capstone\ECG_Code\debug-0362fe.log", "a", encoding="utf-8") as _f:
                _f.write(json.dumps({"sessionId": "0362fe", "runId": "post-fix", "hypothesisId": hid, "location": "testing/serial_rx.py:evaluate", "message": msg, "data": data, "timestamp": int(time.time() * 1000)}) + "\n")
        except Exception:
            pass
    words = [int.from_bytes(frame[i:i + 4], "big") for i in range(0, len(frame), 4)]
    hdr = packer.FrameHeader.from_words(words) if len(words) >= 4 else None
    body = words[config.HEADER_WORDS:] if len(words) >= 4 else []
    ck_calc = packer.payload_checksum(body) if body else None
    body_le = [int.from_bytes(frame[i:i + 4], "little") for i in range(16, len(frame), 4)] if len(frame) >= 16 else []
    ck_le = packer.payload_checksum(body_le) if body_le else None
    _dbg("H1", "frame header and checksum", {
        "frame_bytes": len(frame), "nwords": len(words),
        "sample_count": hdr.sample_count if hdr else None,
        "qrs_count": hdr.qrs_count if hdr else None,
        "checksum_hdr": f"0x{hdr.checksum:08X}" if hdr else None,
        "checksum_calc_be": f"0x{ck_calc:08X}" if ck_calc is not None else None,
        "checksum_ok_be": (ck_calc == hdr.checksum) if hdr and ck_calc is not None else None,
        "checksum_calc_le": f"0x{ck_le:08X}" if ck_le is not None else None,
        "checksum_ok_le": (ck_le == hdr.checksum) if hdr and ck_le is not None else None,
        "first8": [f"0x{w:08X}" for w in words[:8]],
    })
    if record:
        try:
            golden = pipeline.encode_record(record)
            div = None
            gw = golden.words
            for i in range(min(len(words), len(gw))):
                if words[i] != gw[i]:
                    div = {"word": i, "got": f"0x{words[i]:08X}", "golden": f"0x{gw[i]:08X}"}
                    break
            _dbg("H3", "vs golden", {"golden_bytes": len(golden.payload), "got_bytes": len(frame), "first_div": div,
                                     "golden_qrs": (gw[2] >> 16) & 0xFFFF if len(gw) > 2 else None,
                                     "got_qrs": hdr.qrs_count if hdr else None})
        except Exception as _e:
            _dbg("H3", "golden compare failed", {"error": f"{type(_e).__name__}: {_e}"})
    # #endregion
    decoded = packer.decode_frame(frame)
    # #region agent log
    _dbg("H4", "decode_frame ok", {"checksum_ok": decoded.checksum_ok, "segments": decoded.segment_count,
                                   "samples_decoded": int(len(decoded.samples))})
    # #endregion
    result = {
        "sample_count": decoded.header.sample_count,
        "qrs_count": decoded.header.qrs_count,
        "fs": decoded.header.fs,
        "checksum_ok": decoded.checksum_ok,
        "segments": decoded.segment_count,
        "frame_bytes": len(frame),
        "cr": decoded.header.sample_count * config.SAMPLE_BITS / (len(frame) * 8),
    }
    if record is None:
        return result

    original = preprocess.preprocess_record(record)
    n = min(len(original), len(decoded.samples))
    evaluation = metrics.evaluate(
        record=record,
        original=original[:n],
        reconstructed=decoded.samples[:n],
        qrs_mask=decoded.qrs_mask[:n],
        compressed_bits=len(frame) * 8,
        qrs_count=decoded.header.qrs_count,
        segment_count=decoded.segment_count,
        checksum_ok=decoded.checksum_ok,
    )
    result.update({
        "cr": evaluation.compression_ratio,
        "prd_strict": evaluation.prd_overall,
        "prd_baseline": evaluation.prd_overall_baseline,
        "prd_qrs": evaluation.prd_qrs,
        "passed": evaluation.passed,
    })

    # The strongest check available: the board must have produced the same bytes the
    # reference model does, not merely bytes that decode to a similar signal.
    golden = pipeline.encode_record(record)
    result["matches_golden"] = (frame == golden.payload)
    if not result["matches_golden"]:
        got = [int.from_bytes(frame[i:i + 4], "big") for i in range(0, len(frame), 4)]
        result["first_divergence"] = _first_divergence(got, golden.words)
    return result


def _first_divergence(got: list[int], expected: list[int]) -> str:
    for i in range(min(len(got), len(expected))):
        if got[i] != expected[i]:
            return (f"word {i}: received 0x{got[i]:08X}, "
                    f"golden 0x{expected[i]:08X}")
    return f"length differs: received {len(got)} words, golden {len(expected)}"


def report(result: dict, latency_cycles: int) -> bool:
    print(f"  samples      {result['sample_count']}")
    print(f"  beats        {result['qrs_count']}")
    print(f"  segments     {result['segments']}")
    print(f"  frame        {result['frame_bytes']} bytes")
    print(f"  checksum     {'OK' if result['checksum_ok'] else 'MISMATCH'}")
    print(f"  CR           {result['cr']:.2f}")
    if "prd_qrs" in result:
        print(f"  PRD (base)   {result['prd_baseline']:.4f}%")
        print(f"  PRD (strict) {result['prd_strict']:.3f}%")
        print(f"  PRD QRS      {result['prd_qrs']:.3f}%")
    if latency_cycles:
        seconds = latency_cycles / config.CLK_FREQ_HZ
        signal = result["sample_count"] / config.FS
        print(f"  latency      {latency_cycles} PL cycles "
              f"({seconds * 1e3:.2f} ms, {signal / seconds:.0f}x real time)")
    if "matches_golden" in result:
        print(f"  vs golden    "
              f"{'BIT-IDENTICAL' if result['matches_golden'] else 'DIFFERS'}")
        if not result["matches_golden"]:
            print(f"               {result['first_divergence']}")

    ok = result["checksum_ok"] and result.get("passed", True) \
        and result.get("matches_golden", True)
    print(f"  result       {'PASS' if ok else 'FAIL'}")
    return ok


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--port", help="serial port the board is attached to")
    source.add_argument("--file", help="previously captured byte stream")
    source.add_argument("--loopback", metavar="RECORD",
                        help="synthesise the frame from the reference model")
    parser.add_argument("--baud", type=int, default=config.UART_BAUD)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--record", default=None,
                        help="record the board is running, so CR/PRD can be scored")
    parser.add_argument("--save", default=None, help="write the raw frame to this file")
    args = parser.parse_args()

    record = args.record
    link = None

    if args.loopback:
        record = record or args.loopback
        encoded = pipeline.encode_record(args.loopback)
        stream = build_transport_frame(encoded.words, latency_cycles=0)
        print(f"loopback: record {args.loopback}, "
              f"{len(encoded.words)} words synthesised")
        read_exact = reader_from_bytes(stream)
    elif args.file:
        with open(args.file, "rb") as handle:
            read_exact = reader_from_bytes(handle.read())
        print(f"replaying {args.file}")
    else:
        read_exact, link = reader_from_serial(args.port, args.baud, args.timeout)

    t0 = time.time()
    try:
        frame, latency_cycles = read_transport_frame(read_exact)
    except FrameError as exc:
        print(f"receive failed: {exc}")
        return 1
    finally:
        if link is not None:
            link.close()
    print(f"received {len(frame)} bytes in {time.time() - t0:.1f}s")

    if args.save:
        with open(args.save, "wb") as handle:
            handle.write(frame)
        print(f"wrote {args.save}")

    try:
        result = evaluate(frame, record)
    except Exception as exc:  # noqa: BLE001
        print(f"decode failed: {type(exc).__name__}: {exc}")
        return 1

    return 0 if report(result, latency_cycles) else 2


if __name__ == "__main__":
    sys.exit(main())
